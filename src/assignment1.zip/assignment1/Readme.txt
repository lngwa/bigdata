This code provides two solutions to the same problem. One (GenericPair and GenericMain) uses generics and the other (Pair and Main) don't.
To run the program (GenericMain or Main), make sure your file path is correct.
The current path in the code is "input/testDataForW1D1.txt". Make sure to change in the code if your path is different.